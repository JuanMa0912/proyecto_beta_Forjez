# FORJEZ Consulting — Claude + Agent Skills + Stitch Design Pack

Paquete listo para pegar en un repositorio y usar con Claude / Claude Code para construir la presencia digital y/o producto interno de FORJEZ Consulting.

## Qué contiene

```text
.
├── CLAUDE.md
├── DESIGN.md
├── prompts/
│   ├── 00_master_prompt_for_claude.md
│   ├── 01_stitch_prompt_landing_web.md
│   ├── 02_stitch_prompt_admin_dashboard.md
│   ├── 03_claude_implementation_prompt.md
│   └── 04_review_and_hardening_prompt.md
├── .claude/
│   ├── agents/
│   │   ├── product-owner.md
│   │   ├── brand-content-strategist.md
│   │   ├── ux-ui-designer.md
│   │   ├── frontend-engineer.md
│   │   ├── backend-architect.md
│   │   ├── security-reviewer.md
│   │   └── qa-release-manager.md
│   └── skills/
│       ├── forjez-brand-strategy/SKILL.md
│       ├── stitch-ui-design/SKILL.md
│       ├── frontend-implementation/SKILL.md
│       ├── backend-api-data/SKILL.md
│       ├── security-hardening/SKILL.md
│       └── qa-release/SKILL.md
└── docs/
    ├── brand_context.md
    ├── product_scope.md
    ├── functional_requirements.md
    ├── security_requirements.md
    ├── branching_strategy.md
    └── definition_of_done.md
```

## Uso recomendado

1. Copia todo este paquete en la raíz del repositorio.
2. Abre Claude Code en esa carpeta.
3. Empieza con `prompts/00_master_prompt_for_claude.md`.
4. Usa `DESIGN.md` como fuente de verdad visual para Stitch.
5. Para generar UI inicial en Stitch, pega uno de los prompts de la carpeta `prompts/` junto con el contenido de `DESIGN.md`.
6. Cuando Stitch entregue HTML/CSS o capturas, pásalas a Claude y ejecuta `prompts/03_claude_implementation_prompt.md`.

## Objetivo base del proyecto

Construir una plataforma web profesional para FORJEZ Consulting con:

- Landing page corporativa.
- Presentación clara de servicios por pilares.
- Captura de prospectos.
- Dashboard administrativo inicial para leads, diagnósticos, clientes y servicios.
- Base técnica escalable, segura y mantenible.

## Regla de oro

Claude debe evitar alucinaciones. Si falta información, debe dejar `TODO:` explícito o proponer supuestos razonables marcados como `SUPUESTO`, nunca inventar datos sensibles, legales, comerciales o financieros.
